# 六爻起卦 — 阿里云 ECS 部署操作手册

> 用 `alibabacloud-ecs-code-deploy` skill 一键部署到已有 ECS
> 目标：`i-f8z4nozc5klw0izmrtq7`（cn-beijing）

---

## 为什么要你自己跑

OAuth token 有效期 1 小时，且这个 profile 没有 refresh_token，无法自动续期。
每轮对话间隔都会失效，所以部署这几步由你在终端一次跑完最省事。

**全程约 2 分钟。**

---

## 第 0 步：配置环境变量

打开终端，复制这一整段：

```bash
cd /Users/xingyang/Downloads/code/sumsara/01_通用算卦网站/liuyao-divination

export SKILL_DIR="$HOME/.codex/skills/alibabacloud-ecs-code-deploy"
export SESSION_ID=$(uuidgen | tr '[:upper:]' '[:lower:]')
export ALIBABA_CLOUD_USER_AGENT="AlibabaCloud-Agent-Skills/alibabacloud-ecs-code-deploy/${SESSION_ID}"

# 确认脚本存在
test -f "$SKILL_DIR/scripts/deploy_toolkit.py" && echo "✅ SKILL_DIR OK"
```

> `SESSION_ID` 是给阿里云日志做追溯用的，一次会话一个。别每条命令都重新生成。

---

## 第 1 步：环境预检

```bash
python3 "$SKILL_DIR/scripts/deploy_toolkit.py" check
```

**期望输出**：

```
✅ aliyun CLI: 3.4.11 (≥3.3.19)
✅ appmanager-cli: 1.1.5 (≥1.1.1)
✅ credentials: profile=oauth mode=OAuth
✅ All checks passed. Ready to deploy.
```

**如果报凭据失效**（`failed to refresh token`），重新授权：

```bash
aliyun configure --mode OAuth --profile oauth
```

它会开浏览器让你授权，**命令会阻塞到你在浏览器点完授权**。

---

## 第 2 步：初始化项目

```bash
aliyun appmanager init --non-interactive \
  --name liuyao-divination \
  --type app \
  --ecs existing \
  --instance-id i-f8z4nozc5klw0izmrtq7 \
  --region cn-beijing \
  --port 8080
```

跑完会生成 `.appmanager/config.yaml`。

**如果提示 `.appmanager` 已存在**，先备份再删：

```bash
mv .appmanager .appmanager.bak.$(date +%Y%m%d%H%M%S)
```

---

## 第 3 步：写入启停脚本

```bash
python3 write_scripts.py
```

**这一步最关键。** appmanager 会自动生成一份默认脚本，但它不知道你的项目是什么，跑起来必然失败。`write_scripts.py` 做的是把你的启动逻辑替换进去。

它写的内容（脚本已在本目录校验通过）：

| 位置 | 作用 |
|---|---|
| `common.scripts.start` | 装 unzip → 装 python3 → **解压 zip** → 起 http.server:8080 |
| `common.scripts.stop` | 停进程 → 清理目录 |

**验证写入位置正确**：

```bash
python3 -c "
import yaml
c = yaml.safe_load(open('.appmanager/config.yaml'))
s = c['common'].get('scripts', {})
print('start:', 'start' in s)
print('stop :', 'stop' in s)
"
```

两个都要是 `True`。如果写在顶层 `scripts:` 下，部署系统**会忽略它**，然后用默认脚本失败。

---

## 第 4 步：询价

```bash
python3 "$SKILL_DIR/scripts/deploy_toolkit.py" price --config .appmanager/config.yaml
```

会打印价格估算和风险提示。**看清楚再往下走。**

因为我选的是**已有 ECS**，这里可能出现两类提示：

- **[已有 ECS 部署风险]** —— 会往那台机器上装 python3、开 8080 端口。如果机器上已有别的服务，注意端口冲突
- **[分组覆盖风险]** —— 问你覆盖旧分组还是新建

---

## 第 5 步：部署

```bash
python3 "$SKILL_DIR/scripts/deploy_toolkit.py" deploy \
  --type app \
  --name liuyao-divination \
  --group liuyao \
  --region cn-beijing
```

**这一步会花几分钟**，它要把代码打包上传 OSS，再下发到 ECS 执行脚本。

**如果失败**，脚本会报 `ReleaseCancelled`。注意这不是"有人取消了"，而是 **ECS 上的启动脚本报错了**。

不要慌，直接跑第 6 步拿日志。

---

## 第 6 步：验证

```bash
python3 "$SKILL_DIR/scripts/deploy_toolkit.py" verify \
  --type app \
  --name liuyao-divination \
  --group liuyao \
  --region cn-beijing
```

它会去 ECS 上 `cat /root/app.log`，把启动日志抓回来。

**成功的标志**是日志里能看到：

```
=== [liuyao] serving on :8080, pid xxxxx ===
Serving HTTP on 0.0.0.0 port 8080 (http://0.0.0.0:8080/) ...
```

**失败的话**，日志里会有具体的报错，把日志发我。

---

## 第 7 步：放行安全组（必须手动做）

这一步我替不了你，必须去控制台点。

**阿里云控制台 → ECS → 实例 → 找到 `i-f8z4nozc5klw0izmrtq7` → 安全组 → 配置规则 → 入方向 → 手动添加**

| 字段 | 值 |
|---|---|
| 协议类型 | 自定义 TCP |
| 端口范围 | `8080/8080` |
| 授权对象 | `0.0.0.0/0`（或限定你自己的 IP 更安全） |

**不放行的话，部署成功也访问不了。**

---

## 第 8 步：访问

放行后打开：

```
http://<那台 ECS 的公网 IP>:8080
```

公网 IP 在控制台实例列表能看到。

---

## 部署后管理

**查看当前部署**：

```bash
aliyun appmanager app status --output json
```

**删除部署**（停止计费）：

```bash
aliyun appmanager app delete
```

---

## 排查速查

| 现象 | 原因 | 处理 |
|---|---|---|
| `failed to refresh token` | OAuth 过期 | 重跑 `aliyun configure --mode OAuth --profile oauth` |
| `ReleaseCancelled` | ECS 上脚本报错 | 跑 verify 看 `/root/app.log` |
| verify 日志里 `no project zip found` | zip 没传上去/路径不对 | 检查 `ls /root/project_*.zip` |
| verify 日志里 `command not found: python3` | python3 没装上 | 看 yum/dnf 是否可用 |
| 部署成功但网页打不开 | 安全组没放行 / 服务只绑 127.0.0.1 | 检查安全组；启动脚本已显式 `--bind 0.0.0.0` |
| 端口冲突 | 8080 被别的服务占了 | 换端口，改 init 的 `--port` 和启动脚本里的端口号 |

---

## 启动脚本的几个坑（写的时候已经避开）

这几个都是 skill 文档里标出来的高频失败点：

1. **必须解压** —— appmanager 只上传 zip，**不自动解压**。少了 `unzip` 这步，项目目录根本不存在
2. **日志路径写死** —— verify 脚本硬编码读 `/root/app.log`，改了就抓不到
3. **stop 脚本不能有 exit** —— 部署系统把 stop+start 拼成一条命令执行，stop 里有 `exit` 会让 start 永远跑不到
4. **显式绑 0.0.0.0** —— 默认只监听 127.0.0.1，安全组放行了也访问不到
5. **脚本写在 `common.scripts` 下** —— 顶层 `scripts:` 会被忽略

---

## 文件清单

| 文件 | 作用 |
|---|---|
| `index.html` | 站点本体 |
| `README.md` | 开源仓库说明 |
| `LICENSE` | MIT |
| `deploy.sh` | 完整命令序列（本手册的脚本版） |
| `write_scripts.py` | 把启停脚本写进 config.yaml |
| `DEPLOY.md` | 本文件 |
